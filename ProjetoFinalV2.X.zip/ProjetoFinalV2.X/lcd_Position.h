#ifndef LCD_POSITION_H
#define	LCD_POSITION_H

void lcdPosition(unsigned char line, unsigned char column);

#endif	/* LCD_POSITION_H */

